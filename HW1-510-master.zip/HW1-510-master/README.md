# HW1-510

* Cloned the lastest version of https://github.com/CSC-510/REST.
* Then updated my repo HW1-510 to point to the REST Repo that I cloned using:
  * git remote set-url origin https://github.ncsu.edu/USERNAME/REPOSITORY.git
* Ensured to complete the following tasks:
  * Write code for listBranches in a given repo under an owner.
    * Edited the function "listBranches" such that it passes the data - owner, repo name and the HTTP method (GET) to the   getDefaultOptions function. 
    * The getDefaultOptions function returns all the things that should be send in the request as "options". 
    * Then in the function "listBranches" the HTTP request is made and the body of the response is stored in obj variable.  
    * Then using the for loop we iterate through the length of the loop and print the name of all branches under the repo.
    * Also the entire json object having the body of response is returned by the function "listBranches" making the npm tests to pass.
  * Write code for create a new repo
    * The function used for this is "createRepo"
    * The parameters passed while creating the repo is the repo name.
    * Anf the HTTP method changes to POST.
    * This time the function that is being called is getDefaultOptions0 and it contains the appropriate information that should be send in the request.
    * In the code the the value that is returned is "response.statusCode " which makes the npm test pass
  * Write code for creating an issue for an existing repo.
    * The function used for this is "createIssue"
    * The information passed in the function is userId, repo name, name of issue and body of issue.
    * The HTTP method that is used is POST
    * The function that is called this time inside the createIssue function is "getDefaultOptions1"
    * The response code is returned by the function as a result
  * Write code for editing a repo to enable wiki support.
    * The function used is enableWikiSupport 
    * We pass the userId and the repo name in the function to the function "getDefaultOptions2" 
    * Also the HTTP method being used is "PATCH"
    * Finally the function returns the body of the response for the npm test to pass

  * Please find below an attached screen-shot showing that all 5 npm tests are passing.
    * https://media.github.ncsu.edu/user/14795/files/04a90880-d65d-11e9-8193-252824b3f6c1

______________________________________________________________________________________________________________________________
    
* Creating a REST server
  Made changes to the index.js file in the server folder in rest repo.
  
  * Post content to server. Service returns retrieval link
    * The content posted is using command:
      curl --request POST -H "Content-Type: application/json" --data '{"coffee":1,"milk":1,"sugar":1,"chocolate":1}' http://localhost:3000/share
    * The response is as follows:
      {"success":true,"link":"http://localhost:3000/pgiPc2"}
    * When the post request was sent I have stored the body of the response for later use. Further, I have sent another response for the query that I had stored initially.
      
  * Retrieve content
    * We send a GET request to the link "http://localhost:3000/pgiPc2" using the below command:
      curl http://localhost:3000/pgiPc2 
    * The response should be:
      {"coffee":1,"milk":1,"sugar":1,"chocolate":1} 
    * When I get a GET request for the first time I simply sned the body of the response that I saved in the first case.
      
  * A second read will result in "Not Found" message
    * Get request :
      curl http://localhost:3000/pgiPc2
    * Response :
      {"success":false,"error":404,"message":"Not Found"}
    * Here I keep a check, that as the value of count becomes greater than one for the request made to above url, I send another response instead of the actual data that was stored before 
      
  * Link to screencast for the above server running is as follows: https://drive.google.com/drive/folders/1vKjaMiOIazfMb-pyD8D-tBdbxIpgHpt1?usp=sharing
  
 _____________________________________________________________________________________________________________________________
 
* Some concerns related to REST APIs are as follows:
  * Rest APIs basically consist of a collection of endpoints. When we make an API call to fetch data from multiple endpoints, using Rest APIs we will have to make multiple calls one by one to fetch the data appropriately. 
  * If in case we have to to get the data selectively using Rest APIs, we cannot mention in the request about what all data we  actually need. We will get all the data in our response and then we will have to retreive the data that we got from the    response. Hence, we might end up getting more data than we require and then selectively fetching it.
  * Sometimes we might not get all the data that we need, so we will have to make multiple API calls based on the responses we keep getting.
  * In case of versioning when there are different versions of the API. And hence there will be different endpoints. Hence corresponding to various versions of the Rest API there will be different codes that have to be maintained at the server and the Rest API calls will also have to be made accordingly.
  * We keep adding custom endpoints to satisfy growing requirements and usage. Depending on the type of data that is to be retrieved we will create a custom endpoint. Hence scaling of custom APIs becomes a bit hard
  * The compatibility of front end and the backend becomes difficult. Lets say if we make changes to our front end and require some different kind of data, the way in which an API call will be made to the backend will have to be changed. This changing of the API calls on the backend looks like not a good practice.

______________________________________________________________________________________________________________________________

* Benefits and disadvantages of using a RESTful architecture vs. a graph query language:

  * Benefits:
    * Using Graph APIs are prone to resource exhaustion attacks or denial of service attacks. Peopele can attack a Graph server by making complex API calls. In this sense the Rest APIs are very simple and not prone to any exhaustion attacks due to exhaustive queries.

    * Caching is very simple a task in case of Rest APIs. The data is in form of key pairs, and has a kind of dictionary structure making caching simpler. Also, since Rest is based on HTTP, caching does not require building another separate mechanism to cache data. But similarly using query keys in case of GraphQL might lead to data consistency issues. 
    
    * GraphQL is a bit rigid in the sense it does not allow the same flexibility as REST APIs. For example, the Elasticsearch API is RESTful on whose top alot of complex calculations and aggregations are made. However, in case of GraphQL this kind of behaviour is not possible.
    
  * Disadvantages of Rest over Graph Query Language :
    * Using Graph query Language you can fetch as much appropriate amount of data in a single round trip unlike the Rest APIs.
    
    * In case of Graph Query Language the data is requested in a particular way, and it is the responsibility of GQL to return the same data appropriately. Hence, with this ability the development of the backends can be done irrespective of the data requirements. Also, the clients can be treated as seperate form servers. They can be developed seperately. The data requested by the cliends and given by the server will be taken care by the GQL layer.
    
    * The GQL works as a single endpoint unlike the REST APIs. In case of GQL there is a specific way in which the clients can request the data by specifying the appropriate information. This hence can be handled by a single endpoint. Hence due to this ability versioning can be completely avoided in case of GQL. 
    
    * GQL works on a strong type system to define the types of data that can be exposed in an API. All such data is written down in form of a schema using a GraphQL Schema Definition Language. This schema serves as contract between the server and client that they can work independently.
  
The online links that I have used to read and understand about GQL and REST API are as follows:
* https://www.moesif.com/blog/technical/graphql/REST-vs-GraphQL-APIs-the-good-the-bad-the-ugly/#
* https://www.freecodecamp.org/news/rest-apis-are-rest-in-peace-apis-long-live-graphql-d412e559d8e4/
* https://graphql.org/
