const express = require('express')
const app = express()
const port = 3000
const object= {"success":true,"link":"http://localhost:3000/pgiPc2"};
const object2={"success":false,"error":404,"message":"Not Found"};
body= null;
count=0;

// express configuration
app.use(express.json({type: '*/*'}));

// Set your routes
app.get('/', (req, res) => res.send('Hello World!'))

app.post('/', function (req, res) {
    
    res.send(`Received object. ${JSON.stringify(req.body)}`);

});

app.post('/share', function (req, res) {
    
    body=JSON.stringify(req.body);
    //console.log (body);
    //count=count+1;
    res.send(object);

});

//app.get('/' + "pgiPc2", (req, res) => res.send('Hello World!'))

app.get('/' + "pgiPc2", function (req, res){
    if (count == 0)
    {
        res.send(body);
        count=count+1;
    }
    else
    {
    res.send(object2);
    }
});

app.listen(port, () => console.log(`Example app listening on port ${port}!`))